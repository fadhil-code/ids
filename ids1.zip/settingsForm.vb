﻿Imports System.IO
Imports System.Drawing.Imaging
Imports System.Data.OleDb

Public Class settingsForm

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Try
            Dim lists_col, lists_val, did, select_cols, cond As String
            did = depsdt.Rows(deptext.SelectedIndex)("did").ToString
            lists_col = " (sno, sname, engname, sex, bg, dob, did,hd)"
            lists_val = "N'" & snotext.Text & "',N'" & snametext.Text & "',N'" & engnametext.Text & "',N'" & sextext.Text & "',N'" & bgtext.Text.ToString & "',N'" & dobtext.Value.ToShortDateString & "',N'" & did & "',N'" & hd & "'"
            select_cols = "sid,sname as 'اسم الطالب', sno as 'رقم الطالب' , engname as 'الاسم انكليزي', sex as 'الجنس', bg as 'فصيلة الدم', dob as 'تاريخ الميلاد', dname as 'القسم' , dcode as 'رمز القسم' ,hd as 'اقسام داخلية', did  "
            studentsdt = Form1.add_and_select("students", lists_col, lists_val, "View_students", select_cols, "")
            DataGridView1.DataSource = studentsdt
        Catch ex As Exception

        End Try
    End Sub



    Dim depsdt, studentsdt As DataTable

    Private Sub settingsForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try

            Dim lists_col, cond As String
            lists_col = "sid,sname as 'اسم الطالب', sno as 'رقم الطالب' , engname as 'الاسم انكليزي', sex as 'الجنس', bg as 'فصيلة الدم', dob as 'تاريخ الميلاد', dname as 'القسم' , dcode as 'رمز القسم' ,hd as 'اقسام داخلية', did  "

            studentsdt = Form1.select_data("View_students", lists_col, "")
            DataGridView1.DataSource = studentsdt

            lists_col = " did, dname as 'اسم القسم' , dcode as 'رمز القسم' "
            cond = ""
            depsdt = Form1.select_data("departments", lists_col, cond)
            DataGridView2.DataSource = depsdt
            Dim sz = depsdt.Rows.Count - 1
            deptext.Items.Clear()
            For i = 0 To sz
                deptext.Items.Add(depsdt.Rows(i).Item("اسم القسم").ToString)
            Next

            lists_col = "bname as 'اسم العميد', singnimg as 'التوقيع' ,bid"
            Dim dt As DataTable
            dt = Form1.select_data("bosses", lists_col, "")
            DataGridView3.DataSource = dt

            DataGridView3.Columns("التوقيع").Visible = False
            sz = dt.Rows.Count - 1
            For i = 0 To sz
                DataGridView3.Rows(i).Cells("sign").Value = convertstrtoimage(dt.Rows(i).Item("التوقيع").ToString)
            Next
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If idtype.Text = "" Then
            MsgBox("يرجى اختيار نوع الهوية")
        Else
            getdeps()
        End If
    End Sub
    Public Function getdeps()
        Dim lists_col, lists_val As String
        lists_col = " (dname,dcode,idtype)"
        lists_val = "N'" & dnametext.Text & "',N'" & dcodetext.Text & "',N'" & idtype.Text & "'"
        Dim select_col = " did, dname as 'اسم القسم' , dcode as 'رمز القسم' , idtype as 'نوع الهوية' "
        depsdt = Form1.add_and_select("departments", lists_col, lists_val, "departments", select_col, "")
        DataGridView2.DataSource = depsdt
        Dim sz = depsdt.Rows.Count - 1
        deptext.Items.Clear()
        For i = 0 To sz
            deptext.Items.Add(depsdt.Rows(i).Item("اسم القسم").ToString)
        Next
    End Function

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Try

            Dim datat = ""
            Dim strm As MemoryStream = New MemoryStream()
            PictureBox3.Image.Save(strm, System.Drawing.Imaging.ImageFormat.Png)
            datat = Convert.ToBase64String(strm.ToArray)
            '  datat = ConvertImageToString(PictureBox3.Image)
            Dim lists_col, lists_val, did, select_cols, cond As String
            lists_col = " (bname, singnimg)"
            lists_val = "N'" & bnametext.Text & "',N'" & datat & "'"
            select_cols = "bname as 'اسم العميد', singnimg as 'التوقيع',bid "
            Dim dt As DataTable
            dt = Form1.add_and_select("bosses", lists_col, lists_val, "bosses", select_cols, "")
            DataGridView3.DataSource = dt

            DataGridView3.Columns("التوقيع").Visible = False
            Dim sz = dt.Rows.Count - 1
            For i = 0 To sz
                DataGridView3.Rows(i).Cells("sign").Value = convertstrtoimage(dt.Rows(i).Item("التوقيع").ToString)
            Next
        Catch ex As Exception

        End Try
    End Sub


    Public Function convertstrtoimage(ByVal base64 As String)

        Dim imgbyte As Byte() = Convert.FromBase64String(base64)

        Dim ms As MemoryStream = New MemoryStream(imgbyte)
        Dim image = System.Drawing.Image.FromStream(ms)
        Return image
    End Function

    Dim img As Image = Nothing

    Public Function ConvertStringToImage(ByVal imageEncodedString As String) As Image
        Try

            If String.IsNullOrEmpty(imageEncodedString) Then Return Nothing
            Dim mem As New MemoryStream

            Dim buffer = Convert.FromBase64String(imageEncodedString)
            Using mem

                mem.Position = 0

                img = Image.FromStream(mem)
            End Using

            Return img

        Catch ex As Exception

        End Try
    End Function
    Dim szResult As String = ""
    Public Function ConvertImageToString(ByVal value As Image) As String
        If value Is Nothing Then Return ""
        Using ms As New MemoryStream
            value.Save(ms, ImageFormat.Png)
            ms.Flush()
            ms.Position = 0
            Dim buffer = ms.ToArray
            'szResult = System.Text.Encoding.ASCII.GetString(buffer)
            szResult = Convert.ToBase64String(buffer)
        End Using

        Return szResult

    End Function

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            OpenFileDialog1.Filter = "Image(.jpg,.png,.jpeg)|*.jpg;*.png;*.jpeg"
            If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
                Dim signfilepath = OpenFileDialog1.FileName
                PictureBox3.Image = New Bitmap(signfilepath)
                PictureBox3.Show()
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub الواجهةالرئيسيةToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles الواجهةالرئيسيةToolStripMenuItem.Click
        Form1.Show()
        Form1.start()
        Me.Close()
    End Sub

    Private Sub DataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView2.CellContentClick
        Try
            If e.ColumnIndex = 0 Then
                Dim select_col = " did, dname as 'اسم القسم' , dcode as 'رمز القسم' "
                depsdt = Form1.del_and_select("departments", " where did=N'" & DataGridView2.Rows(e.RowIndex).Cells("did").Value.ToString & "'", "departments", select_col, "")
                DataGridView2.DataSource = depsdt
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            If e.ColumnIndex = 0 Then
                Dim select_cols = "sid,sname as 'اسم الطالب', sno as 'رقم الطالب' , engname as 'الاسم انكليزي', sex as 'الجنس', bg as 'فصيلة الدم', dob as 'تاريخ الميلاد', dname as 'القسم' , dcode as 'رمز القسم' , did  "
                studentsdt = Form1.del_and_select("students", " where sid=N'" & DataGridView1.Rows(e.RowIndex).Cells("sid").Value.ToString & "'", "View_students", select_cols, "")
                DataGridView1.DataSource = studentsdt
            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub DataGridView3_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView3.CellContentClick
        Try
            If e.ColumnIndex = 0 Then


                Dim select_cols = "bname as 'اسم العميد', singnimg as 'التوقيع' ,bid"
                Dim dt As DataTable
                dt = Form1.del_and_select("bosses", " where bid=N'" & DataGridView3.Rows(e.RowIndex).Cells("bid").Value.ToString & "'", "bosses", select_cols, "")
                DataGridView3.DataSource = dt

                DataGridView3.Columns("التوقيع").Visible = False
                Dim sz = dt.Rows.Count - 1
                For i = 0 To sz
                    DataGridView3.Rows(i).Cells("sign").Value = convertstrtoimage(dt.Rows(i).Item("التوقيع").ToString)
                Next


            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Try
            If deptext.SelectedIndex < 0 Then
                MsgBox("يجب اختيار القسم")
            Else
                OpenFileDialog2.Title = "يرجى اختيار طلبة " & deptext.Text

                If OpenFileDialog2.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
                    Dim ds As DataSet = get_Q_from_excel(OpenFileDialog2.FileName)
                    IMPORT_STUDENTS(ds, depsdt.Rows(deptext.SelectedIndex).Item("did").ToString)
                    Dim lists_col As String
                    lists_col = "sid,sname as 'اسم الطالب', sno as 'رقم الطالب' , engname as 'الاسم انكليزي', sex as 'الجنس', bg as 'فصيلة الدم', dob as 'تاريخ الميلاد', dname as 'القسم' , dcode as 'رمز القسم', hd as 'اقسام داخلية' , did  "

                    studentsdt = Form1.select_data("View_students", lists_col, "")
                    DataGridView1.DataSource = studentsdt
                End If
            End If

        Catch ex As Exception

        End Try

    End Sub


    Private Function get_Q_from_excel(ByVal _filename As String)
        Try
            Dim _conn As String
            If (Path.GetExtension(_filename).ToLower().Trim() = ".xls" And Environment.Is64BitOperatingSystem = False) Then
                _conn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + _filename + ";Extended Properties= ""Excel 8.0;HDR=Yes;IMEX=2"""
            Else
                _conn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + _filename + ";Extended Properties=""Excel 12.0;HDR=Yes;IMEX=2"""
            End If
            Dim _connection As OleDbConnection = New OleDbConnection(_conn)
            Dim da As OleDbDataAdapter = New OleDbDataAdapter()
            Dim _command As OleDbCommand = New OleDbCommand()
            _command.Connection = _connection
            _command.CommandText = "SELECT * FROM [Sheet1$]"
            da.SelectCommand = _command
            Dim dsFromExcel = New DataSet
            da.Fill(dsFromExcel, "Sheet1&")
            Return dsFromExcel
        Catch e1 As Exception
            MessageBox.Show("هنالك مشكلة في قراءة ملف الاكسل", "", MessageBoxButtons.OK)
        End Try
        Return 0
    End Function

    Private Function IMPORT_STUDENTS(ByRef dsFromExcel As DataSet, ByVal did As String)
        Try
            Dim x = dsFromExcel.Tables(0).Rows.Count
            For i = 0 To x - 1
                Dim sname = (dsFromExcel.Tables(0).Rows(i).Item(0).ToString())
                Dim engname = (dsFromExcel.Tables(0).Rows(i).Item(1).ToString())
                Dim sno = (dsFromExcel.Tables(0).Rows(i).Item(2).ToString())
                Dim sex = (dsFromExcel.Tables(0).Rows(i).Item(3).ToString())
                Dim bg = (dsFromExcel.Tables(0).Rows(i).Item(4).ToString())
                Dim dob = (dsFromExcel.Tables(0).Rows(i).Item(5).ToString())
                Dim hd1 = (dsFromExcel.Tables(0).Rows(i).Item(6).ToString())

                If sname <> "" And sname <> " " And sname <> "  " And sname <> "   " Then
                    Try
                        Dim lists_col, lists_val As String
                        lists_col = " ( sname, engname,sno, sex, bg, dob, did,hd)"
                        lists_val = "N'" & sname & "',N'" & engname & "',N'" & sno & "',N'" & sex & "',N'" & bg & "',N'" & dob & "',N'" & did & "',N'" & hd1 & "'"
                        Form1.add_record("students", lists_col, lists_val)
                    Catch ex As Exception

                    End Try
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return 0
    End Function
    Dim hd As String = "لا"
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            hd = "نعم"
        Else
            hd = "لا"
        End If
    End Sub

    Private Sub معلوماتالعميدToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles معلوماتالعميدToolStripMenuItem.Click
        bossPanel1.BringToFront()
    End Sub

    Private Sub الطلبةToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles الطلبةToolStripMenuItem.Click
        stPanel2.BringToFront()
    End Sub

    Private Sub الاقسامToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles الاقسامToolStripMenuItem.Click
        depPanel3.BringToFront()
    End Sub

    Private Sub idtype_SelectedIndexChanged(sender As Object, e As EventArgs) Handles idtype.SelectedIndexChanged
        Select Case idtype.Text
            Case "احمر"
                PictureBox1.Image = My.Resources.rface
                PictureBox2.Image = My.Resources.rback
            Case "ماروني"

                PictureBox1.Image = My.Resources.mface
                PictureBox2.Image = My.Resources.mback
            Case "برتقالي"

                PictureBox1.Image = My.Resources.oface
                PictureBox2.Image = My.Resources.oback
            Case "اخضر"

                PictureBox1.Image = My.Resources.gface
                PictureBox2.Image = My.Resources.gback
            Case "اخضر فاتح"

                PictureBox1.Image = My.Resources.g2face
                PictureBox2.Image = My.Resources.g2back
            Case "ازرق"

                PictureBox1.Image = My.Resources.bface
                PictureBox2.Image = My.Resources.bback
            Case "ازرق فاتح"

                PictureBox1.Image = My.Resources.b2face
                PictureBox2.Image = My.Resources.b2back

            Case Else

        End Select

    End Sub
End Class