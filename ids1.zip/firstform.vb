﻿Public Class firstform
    Dim x = 0
    Dim CC = 0
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If x = 99 Then
            Timer1.Enabled = False
            Form1.Show()
            Me.Close()
        Else
            x += 1
            BunifuProgressBar1.Value = x
        End If

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub firstform_Load(sender As Object, e As EventArgs) Handles Me.Load
        Me.TransparencyKey = Color.Black
        Me.BackColor = Color.Black
    End Sub

    Private Sub firstform_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Try
            Dim x = GetRandom(0, 13)
            BunifuTransition1.AnimationType = x
            BunifuTransition1.ShowSync(PictureBox1)
        Catch ex As Exception

        End Try

        Timer1.Enabled = True
    End Sub
    Public Function GetRandom(ByVal Min As Integer, ByVal Max As Integer) As Integer
        Dim Generator As System.Random = New System.Random()
        Return Generator.Next(Min, Max)
    End Function

    Private Sub BunifuProgressBar1_progressChanged(sender As Object, e As EventArgs) Handles BunifuProgressBar1.progressChanged

    End Sub
End Class