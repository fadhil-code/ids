﻿Imports Microsoft.Reporting.WinForms
Imports System.Net
Imports System.IO
Imports System.Data.SqlClient

Public Class Form1

    

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Me.ReportViewer1.RefreshReport()
        start()
    End Sub
    Dim studentsdt, depsdt, bossdt As DataTable
    Public Function start()
        Try
            Dim NextTime As Date = Now        ' Current date and time.  
            NextTime = NextTime.AddYears(2)

            DateTimePicker2.Value = NextTime

            stagetext.SelectedIndex = 0
            Dim lists_col, cond As String
            lists_col = "sid,sname , sno  , engname , sex , bg , dob , dname  , dcode,idtype  , did ,hd "

            studentsdt = select_data("View_students", lists_col, "")
            Dim sz = studentsdt.Rows.Count - 1
            nametext.Items.Clear()
            For i = 0 To sz
                nametext.Items.Add(studentsdt.Rows(i).Item("sname").ToString)
            Next

            lists_col = "bname , singnimg  "

            bossdt = select_data("bosses", lists_col, "")


            sz = bossdt.Rows.Count - 1
            PictureBox3.Image = settingsForm.convertstrtoimage(bossdt.Rows(sz).Item("singnimg").ToString)
            bosstext.Items.Clear()
            For i = 0 To sz
                bosstext.Items.Add(bossdt.Rows(i).Item("bname").ToString)
            Next
            bosstext.SelectedIndex = sz
            get_ides()
        Catch ex As Exception

        End Try
    End Function

    Dim st_main As DataTable
    Public Function insert_data()
        Try



            Dim datat = ""
            Dim strm As MemoryStream = New MemoryStream()
            PictureBox2.Image.Save(strm, System.Drawing.Imaging.ImageFormat.Jpeg)
            datat = Convert.ToBase64String(strm.ToArray)

            Dim lists_col, lists_val, did, sid, select_cols, cond As String
            sid = studentsdt(nametext.SelectedIndex)("sid").ToString
            lists_col = " (sid,  stage, d1, d2, img)"
            lists_val = "N'" & sid & "',N'" & stagetext.Text & "',N'" & DateTimePicker1.Text.ToString & "',N'" & DateTimePicker2.Text.ToString & "',N'" & datat & "'"
            Dim updatesql = " update maininfos set stage=N'" & stagetext.Text & "'  , d1=N'" & DateTimePicker1.Text.ToString & "' ,  d2=N'" & DateTimePicker2.Text.ToString & "' ,img=N'" & datat & "'   where sid=N'" & sid & "'"
            Dim insertsql = "insert into maininfos " & lists_col & " values (" & lists_val & ")"
            Dim sql = "  IF EXISTS(select * from maininfos where sid=N'" & sid & "') " & updatesql & " Else    " & insertsql & " "

            select_cols = "Id,sid,sname as 'اسم الطالب', sno as 'رقم الطالب' , dname as 'القسم'  , stage as 'المرحلة', d1 as 'تاريخ الاصدار',d2 as 'تاريخ الانتهاء', hd as 'اقسام داخلية', did,img   "


            '            st_main = add_and_select("maininfos", lists_col, lists_val, "View_students_maininfos2", select_cols, "")
            st_main = addORupdate_and_select(sql, "View_students_maininfos2", select_cols, "")


            DataGridView1.DataSource = st_main
            DataGridView1.Columns("Id").Visible = False
            DataGridView1.Columns("sid").Visible = False
            DataGridView1.Columns("img").Visible = False
            DataGridView1.Columns("did").Visible = False
            Dim sz = st_main.Rows.Count - 1
            For i = 0 To sz
                ' MsgBox(datat.ToString)

                ' DataGridView1.Rows(i).Cells("sign").Value = settingsForm.convertstrtoimage(datat.ToString)
                DataGridView1.Rows(i).Cells("sign").Value = settingsForm.convertstrtoimage(st_main.Rows(i).Item("img").ToString)
            Next
        Catch ex As Exception
        End Try
    End Function

    Public Function get_ides()
        Try
            Dim select_cols = "Id,sid,sname as 'اسم الطالب', sno as 'رقم الطالب' , dname as 'القسم' ,stage as 'المرحلة', d1 as 'تاريخ الاصدار',d2 as 'تاريخ الانتهاء', did,img   "
            st_main = select_data("View_students_maininfos2", select_cols, "")
            DataGridView1.DataSource = st_main
            DataGridView1.Columns("Id").Visible = False
            DataGridView1.Columns("sid").Visible = False
            DataGridView1.Columns("img").Visible = False
            DataGridView1.Columns("did").Visible = False
            Dim sz = st_main.Rows.Count - 1
            For i = 0 To sz
                DataGridView1.Rows(i).Cells("sign").Value = settingsForm.convertstrtoimage(st_main.Rows(i).Item("img").ToString)
            Next
        Catch ex As Exception
        End Try
    End Function
    Dim txtpath = IO.Path.GetDirectoryName(IO.Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory())) & "\Link.txt"
    ' Dim TextFilePath = IO.Path.GetDirectoryName(IO.Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory()))
    'Dim TextFilePath As String = ((System.IO.Directory.GetCurrentDirectory()))
    Dim TextFilePath As String = "|DataDirectory|"
    '"C:\Users\USER\Documents\Visual Studio 2013\Projects\ids\ids\Database1.mdf
    Dim sConnectionString As String _
   = "Data Source=(LocalDB)\v11.0;AttachDbFilename=" & TextFilePath & "\Database1.mdf;Integrated Security=true;"
    Dim objConn As New SqlConnection(sConnectionString)
    Dim sSQL As String
    Dim objCmd As SqlCommand

    Public Function add_id(ByVal tableName As String, ByVal cols As String, ByVal vals As String, ByVal id As String)
        Try
            objConn = New SqlConnection(sConnectionString)
            objConn.Open()
            sSQL = "INSERT INTO " & tableName & _
              cols & _
              " OUTPUT Inserted." & id & " VALUES (" & vals & ")"
            objCmd = New SqlCommand(sSQL, objConn)
            Dim reader As SqlDataReader = objCmd.ExecuteReader
            Dim dt As New DataTable
            dt.Load(reader)
            objConn.Close() : objConn.Dispose()
            Return dt
        Catch e As Exception
            '  MsgBox(e.Message)
            objConn.Close() : objConn.Dispose()
        End Try
    End Function

    Public Function add_record(ByVal tableName As String, ByVal cols As String, ByVal vals As String)
        Try
            objConn = New SqlConnection(sConnectionString)
            objConn.Open()
            sSQL = "INSERT INTO " & tableName & _
              cols & _
              " VALUES (" & vals & ")"
            objCmd = New SqlCommand(sSQL, objConn)
            Dim reader As SqlDataReader = objCmd.ExecuteReader
            '  Dim dt As New DataTable
            ' dt.Load(reader)
            'objConn.Close() : objConn.Dispose()
            'Return dt
        Catch e As Exception
            '  MsgBox(e.Message)
            objConn.Close() : objConn.Dispose()
        End Try
    End Function

    Public Function add_and_select(ByVal tableName As String, ByVal cols As String, ByVal vals As String)
        Try
            objConn = New SqlConnection(sConnectionString)
            objConn.Open()
            sSQL = "INSERT INTO " & tableName & _
              cols & _
              "  VALUES (" & vals & "); select * from " & tableName & ";"
            objCmd = New SqlCommand(sSQL, objConn)
            Dim reader As SqlDataReader = objCmd.ExecuteReader
            Dim dt As New DataTable
            dt.Load(reader)
            objConn.Close() : objConn.Dispose()
            Return dt
        Catch e As Exception
            '  MsgBox(e.Message)
            objConn.Close() : objConn.Dispose()
        End Try
    End Function


    Public Function add_and_select(ByVal tableName As String, ByVal cols As String, ByVal vals As String, ByVal select_table As String, ByVal select_cols As String, ByVal select_cond As String)
        Try
            objConn = New SqlConnection(sConnectionString)
            objConn.Open()
            sSQL = "INSERT INTO " & tableName & _
              cols & _
              "  VALUES (" & vals & "); select " & select_cols & " from " & select_table & " " & select_cond & ";"
            objCmd = New SqlCommand(sSQL, objConn)
            Dim reader As SqlDataReader = objCmd.ExecuteReader
            Dim dt As New DataTable
            dt.Load(reader)
            objConn.Close() : objConn.Dispose()
            Return dt
        Catch e As Exception
            '  MsgBox(e.Message)
            objConn.Close() : objConn.Dispose()
        End Try
    End Function

    Public Function del_and_select(ByVal tableName As String, ByVal delcond As String, ByVal select_table As String, ByVal select_cols As String, ByVal select_cond As String)
        Try
            objConn = New SqlConnection(sConnectionString)
            objConn.Open()
            sSQL = "delete from " & tableName & " " & _
              delcond & " ; select " & select_cols & " from " & select_table & " " & select_cond & ";"
            objCmd = New SqlCommand(sSQL, objConn)
            Dim reader As SqlDataReader = objCmd.ExecuteReader
            Dim dt As New DataTable
            dt.Load(reader)
            objConn.Close() : objConn.Dispose()
            Return dt
        Catch e As Exception
            '  MsgBox(e.Message)
            objConn.Close() : objConn.Dispose()
        End Try
    End Function
    Public Function addORupdate_and_select(ByVal sql As String, ByVal select_table As String, ByVal select_cols As String, ByVal select_cond As String)
        Try
            objConn = New SqlConnection(sConnectionString)
            objConn.Open()
            sSQL = sql & "; select " & select_cols & " from " & select_table & " " & select_cond & ";"
            objCmd = New SqlCommand(sSQL, objConn)
            Dim reader As SqlDataReader = objCmd.ExecuteReader
            Dim dt As New DataTable
            dt.Load(reader)
            objConn.Close() : objConn.Dispose()
            Return dt
        Catch e As Exception
            '  MsgBox(e.Message)
            objConn.Close() : objConn.Dispose()
        End Try
    End Function

    Public Function select_data(ByVal tableName As String, ByVal cols As String, ByVal cond As String)
        Try
            objConn = New SqlConnection(sConnectionString)
            objConn.Open()
            sSQL = " select " & cols & " from " & tableName & " " & cond
            objCmd = New SqlCommand(sSQL, objConn)
            Dim reader As SqlDataReader = objCmd.ExecuteReader
            Dim dt As New DataTable
            dt.Load(reader)
            objConn.Close() : objConn.Dispose()
            Return dt
        Catch e As Exception
            '  MsgBox(e.Message)
            objConn.Close() : objConn.Dispose()
        End Try
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            insert_data()
            R1()
            Dim ff = "C:\نظام الهويات"
            If (Not System.IO.Directory.Exists(ff)) Then
                System.IO.Directory.CreateDirectory(ff)
            End If
            ff = ff & "\" & dnametext.Text & "\"
            If (Not System.IO.Directory.Exists(ff)) Then
                System.IO.Directory.CreateDirectory(ff)
            End If
            save_PDF(ReportViewer1, ff, nametext.Text)

        Catch ex As Exception

        End Try
    End Sub


    Public Function R1()
        Try
            '  ReportViewer1.BringToFront()
            ReportViewer1.LocalReport.DataSources.Clear()
            ReportViewer1.ZoomMode = ZoomMode.PageWidth
            ReportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            Dim ename As New ReportParameter("ename", nametext.Text)
            Dim dep As New ReportParameter("dep", dnametext.Text)
            Dim stage As New ReportParameter("stage", stagetext.Text)
            Dim stid As New ReportParameter("stid", snotext.Text)
            Dim d1 As New ReportParameter("d1", DateTimePicker1.Text.ToString)
            Dim d2 As New ReportParameter("d2", DateTimePicker2.Text.ToString)
            Dim boss As New ReportParameter("boss", bosstext.Text)
            Dim strm1 As MemoryStream = New MemoryStream()
            PictureBox2.Image.Save(strm1, System.Drawing.Imaging.ImageFormat.Png)
            Dim datat1 As String = Convert.ToBase64String(strm1.ToArray)
            Dim img2 As New ReportParameter("img", datat1)

            Dim strm As MemoryStream = New MemoryStream()
            PictureBox3.Image.Save(strm, System.Drawing.Imaging.ImageFormat.Png)
            Dim datat As String = Convert.ToBase64String(strm.ToArray)
            Dim sign2 As New ReportParameter("sign", datat)

            Dim engname As New ReportParameter("engname", engnametext.Text)
            Dim dob As New ReportParameter("dob", dobtext.Text)
            Dim depcode As New ReportParameter("dcode", dcodetext.Text)
            Dim gen As New ReportParameter("gen", sextext.Text)
            Dim bg As New ReportParameter("bg", bgtext.Text)
            Dim bcolor As New ReportParameter("bcolor", idtype.Text)
            '  idtype.Text = studentsdt(ind)("idtype").ToString()
            '  Dim hd1p As String = ""
            '  Dim hd2p As String = ""
            Dim strm2 As MemoryStream = New MemoryStream()
            Dim strm3 As MemoryStream = New MemoryStream()
            Dim datat2 As String = ""
            Dim datat3 As String = ""

            Select Case idtype.Text
                Case "احمر"
                    My.Resources.rface.Save(strm2, System.Drawing.Imaging.ImageFormat.Png)
                    datat2 = Convert.ToBase64String(strm2.ToArray)
                    My.Resources.rback.Save(strm3, System.Drawing.Imaging.ImageFormat.Png)
                    datat3 = Convert.ToBase64String(strm3.ToArray)
                Case "ماروني"

                    My.Resources.mface.Save(strm2, System.Drawing.Imaging.ImageFormat.Png)
                    datat2 = Convert.ToBase64String(strm2.ToArray)
                    My.Resources.mback.Save(strm3, System.Drawing.Imaging.ImageFormat.Png)
                    datat3 = Convert.ToBase64String(strm3.ToArray)
                Case "برتقالي"

                    My.Resources.oface.Save(strm2, System.Drawing.Imaging.ImageFormat.Png)
                    datat2 = Convert.ToBase64String(strm2.ToArray)
                    My.Resources.oback.Save(strm3, System.Drawing.Imaging.ImageFormat.Png)
                    datat3 = Convert.ToBase64String(strm3.ToArray)
                Case "اخضر"
                    My.Resources.gface.Save(strm2, System.Drawing.Imaging.ImageFormat.Png)
                    datat2 = Convert.ToBase64String(strm2.ToArray)
                    My.Resources.gback.Save(strm3, System.Drawing.Imaging.ImageFormat.Png)
                    datat3 = Convert.ToBase64String(strm3.ToArray)
                Case "اخضر فاتح"

                    My.Resources.g2face.Save(strm2, System.Drawing.Imaging.ImageFormat.Png)
                    datat2 = Convert.ToBase64String(strm2.ToArray)
                    My.Resources.g2back.Save(strm3, System.Drawing.Imaging.ImageFormat.Png)
                    datat3 = Convert.ToBase64String(strm3.ToArray)
                Case "ازرق"

                    My.Resources.bface.Save(strm2, System.Drawing.Imaging.ImageFormat.Png)
                    datat2 = Convert.ToBase64String(strm2.ToArray)
                    My.Resources.bback.Save(strm3, System.Drawing.Imaging.ImageFormat.Png)
                    datat3 = Convert.ToBase64String(strm3.ToArray)
                Case "ازرق فاتح"

                    My.Resources.b2face.Save(strm2, System.Drawing.Imaging.ImageFormat.Png)
                    datat2 = Convert.ToBase64String(strm2.ToArray)
                    My.Resources.b2back.Save(strm3, System.Drawing.Imaging.ImageFormat.Png)
                    datat3 = Convert.ToBase64String(strm3.ToArray)
                Case Else

            End Select

            Dim imgf As New ReportParameter("imgf", datat2)
            Dim imgb As New ReportParameter("imgb", datat3)

            '  Dim hd1 As New ReportParameter("hd1", hd1p) '[@hd1]
            '  Dim hd2 As New ReportParameter("hd2", hd2p) '[@hd2]

            ReportViewer1.LocalReport.EnableExternalImages = True
            Me.ReportViewer1.LocalReport.SetParameters(New ReportParameter() {ename, dep, stage, stid, d1, d2, boss, img2, sign2, engname, dob, depcode, gen, bg, imgf, imgb})
            Me.ReportViewer1.ServerReport.Refresh()
        Catch ex As Exception
            ' RichTextBox1.Text = (ex.ToString)
        End Try
        Me.ReportViewer1.RefreshReport()

    End Function


    Dim strfilepath As String = ""
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            OpenFileDialog1.Filter = "Image(.jpg,.png,.jpeg)|*.jpg;*.png;*.jpeg"
            If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
                strfilepath = OpenFileDialog1.FileName
                PictureBox2.Image = New Bitmap(strfilepath)
                PictureBox2.Show()
            End If
        Catch ex As Exception
        End Try
    End Sub

    Dim signfilepath As String = ""

    Private Sub Button3_Click(sender As Object, e As EventArgs)
        Try
            OpenFileDialog1.Filter = "Image(.jpg,.png,.jpeg)|*.jpg;*.png;*.jpeg"
            If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
                signfilepath = OpenFileDialog1.FileName
                PictureBox3.Image = New Bitmap(signfilepath)
                PictureBox3.Show()
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub الاعداداتToolStripMenuItem_Click(sender As Object, e As EventArgs)

        '        settingsForm.ShowDialog()
        Me.Close()
    End Sub

    Private Sub enametext_TextChanged(sender As Object, e As EventArgs) Handles engnametext.TextChanged

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Try
            OpenFileDialog1.Filter = "Image(.jpg,.png,.jpeg)|*.jpg;*.png;*.jpeg"
            If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
                strfilepath = OpenFileDialog1.FileName
                PictureBox2.Image = New Bitmap(strfilepath)
                PictureBox2.Show()
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub bosstext_SelectedIndexChanged(sender As Object, e As EventArgs) Handles bosstext.SelectedIndexChanged
        PictureBox3.Image = settingsForm.convertstrtoimage(bossdt.Rows(bosstext.SelectedIndex).Item("singnimg").ToString)

    End Sub

    Private Sub nametext_SelectedIndexChanged(sender As Object, e As EventArgs) Handles nametext.SelectedIndexChanged
        Try
            Dim ind = nametext.SelectedIndex
            snotext.Text = studentsdt(ind)("sno").ToString()
            engnametext.Text = studentsdt(ind)("engname").ToString()
            sextext.Text = studentsdt(ind)("sex").ToString()
            bgtext.Text = studentsdt(ind)("bg").ToString()
            dobtext.Text = studentsdt(ind)("dob").ToString()
            dnametext.Text = studentsdt(ind)("dname").ToString()
            dcodetext.Text = studentsdt(ind)("dcode").ToString()
            idtype.Text = studentsdt(ind)("idtype").ToString()
            hdtext.Text = studentsdt(ind)("hd").ToString()
            sextext.Text = studentsdt(ind)("sex").ToString()
            idtype.Text = studentsdt(ind)("idtype").ToString()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            If e.ColumnIndex = 0 Then
                Dim select_cols = "Id,sid,sname as 'اسم الطالب', sno as 'رقم الطالب' , dname as 'القسم' ,stage as 'المرحلة', d1 as 'تاريخ الاصدار',d2 as 'تاريخ الانتهاء', did,img   "
                st_main = del_and_select("maininfos", " where sid=N'" & DataGridView1.Rows(e.RowIndex).Cells("sid").Value.ToString & "'", "View_students_maininfos2", select_cols, "")
                DataGridView1.DataSource = st_main
                DataGridView1.DataSource = st_main
                DataGridView1.Columns("Id").Visible = False
                DataGridView1.Columns("sid").Visible = False
                DataGridView1.Columns("img").Visible = False
                DataGridView1.Columns("did").Visible = False
                Dim sz = st_main.Rows.Count - 1
                For i = 0 To sz
                    DataGridView1.Rows(i).Cells("sign").Value = settingsForm.convertstrtoimage(st_main.Rows(i).Item("img").ToString)
                Next
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub DataGridView1_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentDoubleClick

        '   MsgBox(st_main.Rows(e.RowIndex).Item("sid").ToString)
        '  MsgBox(DataGridView1.Rows(e.RowIndex).Cells("sid").Value.ToString)



    End Sub

    Public Function save_PDF(ByVal Rviewer As ReportViewer, ByVal path As String, ByVal fname As String)
        Try '
            Dim newFile As FileStream
            Dim byteViewer As Byte()
            ' Reports_view_Form.R5()
            byteViewer = Rviewer.LocalReport.Render("PDF")
            SaveFileDialog1 = New SaveFileDialog()
            SaveFileDialog1.FilterIndex = 2
            SaveFileDialog1.RestoreDirectory = True
            SaveFileDialog1.FileName = path
            newFile = New FileStream(path & fname & ".pdf", FileMode.Create)
            newFile.Write(byteViewer, 0, byteViewer.Length)
            newFile.Close()
        Catch ex As Exception

        End Try
    End Function

    Private Sub Button3_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub الواجهةالرئيسيةToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles الواجهةالرئيسيةToolStripMenuItem.Click
        settingsForm.Show()
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        Try
            nametext.SelectedIndex = e.RowIndex
            PictureBox2.Image = settingsForm.convertstrtoimage(st_main.Rows(e.RowIndex).Item("img").ToString)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        ColorDialog1.ShowDialog()
        Label1.BackColor = ColorDialog1.Color

    End Sub
End Class
