﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class settingsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(settingsForm))
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.snametext = New System.Windows.Forms.TextBox()
        Me.sextext = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.bgtext = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.dobtext = New System.Windows.Forms.DateTimePicker()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.engnametext = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.snotext = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.dcodetext = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dnametext = New System.Windows.Forms.TextBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.bnametext = New System.Windows.Forms.TextBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.del = New System.Windows.Forms.DataGridViewImageColumn()
        Me.deptext = New System.Windows.Forms.ComboBox()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.sign = New System.Windows.Forms.DataGridViewImageColumn()
        Me.bossPanel1 = New System.Windows.Forms.Panel()
        Me.stPanel2 = New System.Windows.Forms.Panel()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewImageColumn1 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.depPanel3 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.idtype = New System.Windows.Forms.ComboBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.الواجهةالرئيسيةToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.الاقسامToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.معلوماتالعميدToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.الطلبةToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenFileDialog2 = New System.Windows.Forms.OpenFileDialog()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.bossPanel1.SuspendLayout()
        Me.stPanel2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.depPanel3.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(2296, 110)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 32)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "الاسم"
        '
        'snametext
        '
        Me.snametext.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.snametext.Location = New System.Drawing.Point(1675, 86)
        Me.snametext.Margin = New System.Windows.Forms.Padding(5)
        Me.snametext.Multiline = True
        Me.snametext.Name = "snametext"
        Me.snametext.Size = New System.Drawing.Size(604, 52)
        Me.snametext.TabIndex = 8
        '
        'sextext
        '
        Me.sextext.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.sextext.FormattingEnabled = True
        Me.sextext.Items.AddRange(New Object() {"Male", "Female"})
        Me.sextext.Location = New System.Drawing.Point(2040, 255)
        Me.sextext.Margin = New System.Windows.Forms.Padding(5)
        Me.sextext.Name = "sextext"
        Me.sextext.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.sextext.Size = New System.Drawing.Size(239, 39)
        Me.sextext.TabIndex = 12
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(1888, 274)
        Me.Label12.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(111, 32)
        Me.Label12.TabIndex = 121
        Me.Label12.Text = "فصيلة الدم"
        '
        'bgtext
        '
        Me.bgtext.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bgtext.Location = New System.Drawing.Point(1675, 253)
        Me.bgtext.Margin = New System.Windows.Forms.Padding(5)
        Me.bgtext.Multiline = True
        Me.bgtext.Name = "bgtext"
        Me.bgtext.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.bgtext.Size = New System.Drawing.Size(199, 52)
        Me.bgtext.TabIndex = 13
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(2296, 279)
        Me.Label11.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(73, 32)
        Me.Label11.TabIndex = 119
        Me.Label11.Text = "الجنس"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(1387, 274)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(130, 32)
        Me.Label9.TabIndex = 118
        Me.Label9.Text = "تاريخ الميلاد"
        '
        'dobtext
        '
        Me.dobtext.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dobtext.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dobtext.Location = New System.Drawing.Point(1131, 255)
        Me.dobtext.Margin = New System.Windows.Forms.Padding(5)
        Me.dobtext.Name = "dobtext"
        Me.dobtext.Size = New System.Drawing.Size(239, 46)
        Me.dobtext.TabIndex = 14
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(1387, 105)
        Me.Label8.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(213, 32)
        Me.Label8.TabIndex = 116
        Me.Label8.Text = "اسم الطالب (انكليزي)"
        '
        'engnametext
        '
        Me.engnametext.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.engnametext.Location = New System.Drawing.Point(659, 91)
        Me.engnametext.Margin = New System.Windows.Forms.Padding(5)
        Me.engnametext.Multiline = True
        Me.engnametext.Name = "engnametext"
        Me.engnametext.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.engnametext.Size = New System.Drawing.Size(711, 52)
        Me.engnametext.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(1387, 200)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(137, 32)
        Me.Label6.TabIndex = 112
        Me.Label6.Text = "الرقم الطلابي"
        '
        'snotext
        '
        Me.snotext.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.snotext.Location = New System.Drawing.Point(995, 172)
        Me.snotext.Margin = New System.Windows.Forms.Padding(5)
        Me.snotext.Multiline = True
        Me.snotext.Name = "snotext"
        Me.snotext.Size = New System.Drawing.Size(375, 56)
        Me.snotext.TabIndex = 11
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(2296, 200)
        Me.Label2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 32)
        Me.Label2.TabIndex = 111
        Me.Label2.Text = "القسم"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(2366, 172)
        Me.Label10.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(109, 32)
        Me.Label10.TabIndex = 126
        Me.Label10.Text = "رمز القسم"
        '
        'dcodetext
        '
        Me.dcodetext.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dcodetext.Location = New System.Drawing.Point(1964, 144)
        Me.dcodetext.Margin = New System.Windows.Forms.Padding(5)
        Me.dcodetext.Multiline = True
        Me.dcodetext.Name = "dcodetext"
        Me.dcodetext.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.dcodetext.Size = New System.Drawing.Size(387, 52)
        Me.dcodetext.TabIndex = 125
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(2372, 101)
        Me.Label3.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 32)
        Me.Label3.TabIndex = 123
        Me.Label3.Text = "القسم"
        '
        'dnametext
        '
        Me.dnametext.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dnametext.Location = New System.Drawing.Point(1523, 72)
        Me.dnametext.Margin = New System.Windows.Forms.Padding(5)
        Me.dnametext.Multiline = True
        Me.dnametext.Name = "dnametext"
        Me.dnametext.Size = New System.Drawing.Size(831, 56)
        Me.dnametext.TabIndex = 124
        '
        'PictureBox3
        '
        Me.PictureBox3.Location = New System.Drawing.Point(1200, 155)
        Me.PictureBox3.Margin = New System.Windows.Forms.Padding(5)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(611, 107)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 128
        Me.PictureBox3.TabStop = False
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(1200, 272)
        Me.Button3.Margin = New System.Windows.Forms.Padding(5)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(611, 107)
        Me.Button3.TabIndex = 130
        Me.Button3.Text = "رفع صورة توقيع العميد"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label7.Location = New System.Drawing.Point(1899, 114)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(113, 32)
        Me.Label7.TabIndex = 127
        Me.Label7.Text = "عميد الكلية"
        '
        'bnametext
        '
        Me.bnametext.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bnametext.Location = New System.Drawing.Point(1107, 83)
        Me.bnametext.Margin = New System.Windows.Forms.Padding(5)
        Me.bnametext.Multiline = True
        Me.bnametext.Name = "bnametext"
        Me.bnametext.Size = New System.Drawing.Size(775, 56)
        Me.bnametext.TabIndex = 129
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1533, 353)
        Me.Button1.Margin = New System.Windows.Forms.Padding(5)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(315, 76)
        Me.Button1.TabIndex = 15
        Me.Button1.Text = "حفظ"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(1675, 274)
        Me.Button2.Margin = New System.Windows.Forms.Padding(5)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(397, 83)
        Me.Button2.TabIndex = 132
        Me.Button2.Text = "حفظ"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(1200, 396)
        Me.Button4.Margin = New System.Windows.Forms.Padding(5)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(611, 107)
        Me.Button4.TabIndex = 133
        Me.Button4.Text = "حفظ"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToDeleteRows = False
        Me.DataGridView2.BackgroundColor = System.Drawing.Color.White
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.del})
        Me.DataGridView2.Location = New System.Drawing.Point(589, 396)
        Me.DataGridView2.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.ReadOnly = True
        Me.DataGridView2.Size = New System.Drawing.Size(1829, 575)
        Me.DataGridView2.TabIndex = 135
        '
        'del
        '
        Me.del.HeaderText = "مسح"
        Me.del.Image = CType(resources.GetObject("del.Image"), System.Drawing.Image)
        Me.del.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch
        Me.del.Name = "del"
        Me.del.ReadOnly = True
        Me.del.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.del.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.del.Width = 35
        '
        'deptext
        '
        Me.deptext.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.deptext.FormattingEnabled = True
        Me.deptext.Location = New System.Drawing.Point(1675, 184)
        Me.deptext.Margin = New System.Windows.Forms.Padding(5)
        Me.deptext.Name = "deptext"
        Me.deptext.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.deptext.Size = New System.Drawing.Size(604, 39)
        Me.deptext.TabIndex = 10
        '
        'DataGridView3
        '
        Me.DataGridView3.AllowUserToAddRows = False
        Me.DataGridView3.AllowUserToDeleteRows = False
        Me.DataGridView3.BackgroundColor = System.Drawing.Color.White
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.sign})
        Me.DataGridView3.Location = New System.Drawing.Point(659, 515)
        Me.DataGridView3.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.ReadOnly = True
        Me.DataGridView3.Size = New System.Drawing.Size(1659, 455)
        Me.DataGridView3.TabIndex = 137
        '
        'Column1
        '
        Me.Column1.HeaderText = "مسح"
        Me.Column1.Image = CType(resources.GetObject("Column1.Image"), System.Drawing.Image)
        Me.Column1.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 35
        '
        'sign
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle4.NullValue = CType(resources.GetObject("DataGridViewCellStyle4.NullValue"), Object)
        Me.sign.DefaultCellStyle = DataGridViewCellStyle4
        Me.sign.HeaderText = "التوقيع"
        Me.sign.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch
        Me.sign.Name = "sign"
        Me.sign.ReadOnly = True
        '
        'bossPanel1
        '
        Me.bossPanel1.BackColor = System.Drawing.Color.Transparent
        Me.bossPanel1.Controls.Add(Me.DataGridView3)
        Me.bossPanel1.Controls.Add(Me.bnametext)
        Me.bossPanel1.Controls.Add(Me.Label7)
        Me.bossPanel1.Controls.Add(Me.Button3)
        Me.bossPanel1.Controls.Add(Me.PictureBox3)
        Me.bossPanel1.Controls.Add(Me.Button4)
        Me.bossPanel1.Location = New System.Drawing.Point(152, 234)
        Me.bossPanel1.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.bossPanel1.Name = "bossPanel1"
        Me.bossPanel1.Size = New System.Drawing.Size(3125, 1171)
        Me.bossPanel1.TabIndex = 139
        '
        'stPanel2
        '
        Me.stPanel2.BackColor = System.Drawing.Color.Transparent
        Me.stPanel2.Controls.Add(Me.CheckBox1)
        Me.stPanel2.Controls.Add(Me.Button5)
        Me.stPanel2.Controls.Add(Me.DataGridView1)
        Me.stPanel2.Controls.Add(Me.engnametext)
        Me.stPanel2.Controls.Add(Me.snametext)
        Me.stPanel2.Controls.Add(Me.deptext)
        Me.stPanel2.Controls.Add(Me.Label1)
        Me.stPanel2.Controls.Add(Me.Label2)
        Me.stPanel2.Controls.Add(Me.snotext)
        Me.stPanel2.Controls.Add(Me.Label6)
        Me.stPanel2.Controls.Add(Me.Button1)
        Me.stPanel2.Controls.Add(Me.Label8)
        Me.stPanel2.Controls.Add(Me.dobtext)
        Me.stPanel2.Controls.Add(Me.Label9)
        Me.stPanel2.Controls.Add(Me.Label11)
        Me.stPanel2.Controls.Add(Me.bgtext)
        Me.stPanel2.Controls.Add(Me.sextext)
        Me.stPanel2.Controls.Add(Me.Label12)
        Me.stPanel2.Location = New System.Drawing.Point(152, 234)
        Me.stPanel2.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.stPanel2.Name = "stPanel2"
        Me.stPanel2.Size = New System.Drawing.Size(3125, 1171)
        Me.stPanel2.TabIndex = 140
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox1.ForeColor = System.Drawing.Color.White
        Me.CheckBox1.Location = New System.Drawing.Point(760, 191)
        Me.CheckBox1.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(165, 36)
        Me.CheckBox1.TabIndex = 138
        Me.CheckBox1.Text = "اقسام داخلية"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(1208, 353)
        Me.Button5.Margin = New System.Windows.Forms.Padding(5)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(315, 76)
        Me.Button5.TabIndex = 16
        Me.Button5.Text = "اضافة مجموعة اسماء"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewImageColumn1})
        Me.DataGridView1.Location = New System.Drawing.Point(43, 441)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(3035, 637)
        Me.DataGridView1.TabIndex = 137
        '
        'DataGridViewImageColumn1
        '
        Me.DataGridViewImageColumn1.HeaderText = "مسح"
        Me.DataGridViewImageColumn1.Image = CType(resources.GetObject("DataGridViewImageColumn1.Image"), System.Drawing.Image)
        Me.DataGridViewImageColumn1.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch
        Me.DataGridViewImageColumn1.Name = "DataGridViewImageColumn1"
        Me.DataGridViewImageColumn1.ReadOnly = True
        Me.DataGridViewImageColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewImageColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewImageColumn1.Width = 35
        '
        'depPanel3
        '
        Me.depPanel3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.depPanel3.BackColor = System.Drawing.Color.Transparent
        Me.depPanel3.Controls.Add(Me.PictureBox2)
        Me.depPanel3.Controls.Add(Me.PictureBox1)
        Me.depPanel3.Controls.Add(Me.Label4)
        Me.depPanel3.Controls.Add(Me.idtype)
        Me.depPanel3.Controls.Add(Me.dcodetext)
        Me.depPanel3.Controls.Add(Me.dnametext)
        Me.depPanel3.Controls.Add(Me.Label3)
        Me.depPanel3.Controls.Add(Me.DataGridView2)
        Me.depPanel3.Controls.Add(Me.Label10)
        Me.depPanel3.Controls.Add(Me.Button2)
        Me.depPanel3.Location = New System.Drawing.Point(152, 234)
        Me.depPanel3.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.depPanel3.Name = "depPanel3"
        Me.depPanel3.Size = New System.Drawing.Size(3125, 1171)
        Me.depPanel3.TabIndex = 141
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(609, 72)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(451, 286)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 139
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(1066, 71)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(451, 286)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 138
        Me.PictureBox1.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(1772, 156)
        Me.Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(110, 32)
        Me.Label4.TabIndex = 137
        Me.Label4.Text = "نوع الهوية"
        '
        'idtype
        '
        Me.idtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.idtype.FormattingEnabled = True
        Me.idtype.Items.AddRange(New Object() {"احمر", "ماروني", "برتقالي", "اخضر", "اخضر فاتح", "ازرق", "ازرق فاتح"})
        Me.idtype.Location = New System.Drawing.Point(1523, 157)
        Me.idtype.Margin = New System.Windows.Forms.Padding(5)
        Me.idtype.Name = "idtype"
        Me.idtype.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.idtype.Size = New System.Drawing.Size(239, 39)
        Me.idtype.TabIndex = 126
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.White
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.الواجهةالرئيسيةToolStripMenuItem, Me.الاقسامToolStripMenuItem, Me.معلوماتالعميدToolStripMenuItem, Me.الطلبةToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 1463)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(16, 5, 0, 5)
        Me.MenuStrip1.Size = New System.Drawing.Size(3204, 68)
        Me.MenuStrip1.TabIndex = 142
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'الواجهةالرئيسيةToolStripMenuItem
        '
        Me.الواجهةالرئيسيةToolStripMenuItem.Name = "الواجهةالرئيسيةToolStripMenuItem"
        Me.الواجهةالرئيسيةToolStripMenuItem.Size = New System.Drawing.Size(161, 58)
        Me.الواجهةالرئيسيةToolStripMenuItem.Text = "الهويات"
        '
        'الاقسامToolStripMenuItem
        '
        Me.الاقسامToolStripMenuItem.Name = "الاقسامToolStripMenuItem"
        Me.الاقسامToolStripMenuItem.Size = New System.Drawing.Size(154, 58)
        Me.الاقسامToolStripMenuItem.Text = "الاقسام"
        '
        'معلوماتالعميدToolStripMenuItem
        '
        Me.معلوماتالعميدToolStripMenuItem.Name = "معلوماتالعميدToolStripMenuItem"
        Me.معلوماتالعميدToolStripMenuItem.Size = New System.Drawing.Size(297, 58)
        Me.معلوماتالعميدToolStripMenuItem.Text = "معلومات العميد"
        '
        'الطلبةToolStripMenuItem
        '
        Me.الطلبةToolStripMenuItem.Name = "الطلبةToolStripMenuItem"
        Me.الطلبةToolStripMenuItem.Size = New System.Drawing.Size(137, 58)
        Me.الطلبةToolStripMenuItem.Text = "الطلبة"
        '
        'OpenFileDialog2
        '
        Me.OpenFileDialog2.FileName = "OpenFileDialog1"
        '
        'settingsForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(16.0!, 31.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(3204, 1531)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.bossPanel1)
        Me.Controls.Add(Me.depPanel3)
        Me.Controls.Add(Me.stPanel2)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(8, 7, 8, 7)
        Me.Name = "settingsForm"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "settingsForm"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.bossPanel1.ResumeLayout(False)
        Me.bossPanel1.PerformLayout()
        Me.stPanel2.ResumeLayout(False)
        Me.stPanel2.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.depPanel3.ResumeLayout(False)
        Me.depPanel3.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents snametext As System.Windows.Forms.TextBox
    Friend WithEvents sextext As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents bgtext As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents dobtext As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents engnametext As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents snotext As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents dcodetext As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents dnametext As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents bnametext As System.Windows.Forms.TextBox
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents deptext As System.Windows.Forms.ComboBox
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents bossPanel1 As System.Windows.Forms.Panel
    Friend WithEvents stPanel2 As System.Windows.Forms.Panel
    Friend WithEvents depPanel3 As System.Windows.Forms.Panel
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents الواجهةالرئيسيةToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents del As System.Windows.Forms.DataGridViewImageColumn
    Friend WithEvents DataGridViewImageColumn1 As System.Windows.Forms.DataGridViewImageColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewImageColumn
    Friend WithEvents sign As System.Windows.Forms.DataGridViewImageColumn
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents الاقسامToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents معلوماتالعميدToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents الطلبةToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenFileDialog2 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents idtype As System.Windows.Forms.ComboBox
End Class
